var searchData=
[
  ['access_0',['Native access',['../group__native.html',1,'']]],
  ['and_20error_20reference_1',['Initialization, version and error reference',['../group__init.html',1,'']]],
  ['axes_2',['Gamepad axes',['../group__gamepad__axes.html',1,'']]]
];
